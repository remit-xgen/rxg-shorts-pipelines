def extract_audio(video_path:str):
    print("Extracting audio from", video_path)
