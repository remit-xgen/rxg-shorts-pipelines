def normalize_video(path:str)->str:
    print("Normalizing video:", path)
    return path
