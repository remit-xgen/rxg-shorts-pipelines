def sample_frames(video_path:str):
    print("Sampling frames from", video_path)
