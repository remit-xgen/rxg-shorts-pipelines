class CacheManager:
    def get(self, key):
        return None
    def set(self, key, value):
        pass
