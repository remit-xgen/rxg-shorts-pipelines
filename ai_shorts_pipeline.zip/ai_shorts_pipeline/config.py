class Config:
    OUTPUT_DIR = "outputs"
    CACHE_DIR = "cache"
    TEMP_DIR = "temp"
    MAX_PARALLEL_JOBS = 4
