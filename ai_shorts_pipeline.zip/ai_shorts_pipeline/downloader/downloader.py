def download_video(url:str)->str:
    print("Downloading video:", url)
    return "video.mp4"
