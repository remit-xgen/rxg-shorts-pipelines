def filter_low_quality(clips):
    print("Filtering clips")
