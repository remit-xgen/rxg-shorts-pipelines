def generate_caption(clip):
    return "Generated caption"
