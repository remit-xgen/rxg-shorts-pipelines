def apply_zoom(clip):
    print("Applying zoom")
