def apply_emphasis(clip):
    print("Applying emphasis")
