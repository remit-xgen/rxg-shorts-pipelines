def apply_motion(clip):
    print("Applying motion effects")
