def generate_subtitles(transcript):
    print("Generating subtitles")
