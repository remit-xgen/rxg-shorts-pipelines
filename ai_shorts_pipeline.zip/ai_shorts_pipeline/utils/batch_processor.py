def batch_process(items, fn):
    return [fn(i) for i in items]
