def select_best_clips(scored_clips):
    print("Selecting clips")
