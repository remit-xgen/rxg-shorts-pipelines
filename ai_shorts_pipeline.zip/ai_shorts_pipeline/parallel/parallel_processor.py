from concurrent.futures import ThreadPoolExecutor

def run_parallel(tasks, fn, max_workers=4):
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        return list(ex.map(fn, tasks))
