import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("ai_shorts_pipeline")
