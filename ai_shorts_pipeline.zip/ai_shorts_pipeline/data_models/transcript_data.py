class TranscriptData:
    def __init__(self, text:str, timestamps:list):
        self.text = text
        self.timestamps = timestamps
