class VideoData:
    def __init__(self, path:str):
        self.path = path
        self.duration = None
        self.fps = None
