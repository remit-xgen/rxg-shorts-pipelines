class ClipData:
    def __init__(self, start:float, end:float, score:float=0):
        self.start = start
        self.end = end
        self.score = score
