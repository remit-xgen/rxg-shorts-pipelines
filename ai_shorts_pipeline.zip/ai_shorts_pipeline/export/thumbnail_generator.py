def generate_thumbnail(clip):
    print("Generating thumbnail")
