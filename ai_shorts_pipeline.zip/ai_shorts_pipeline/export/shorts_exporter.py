def export_short(clip):
    print("Exporting short video")
