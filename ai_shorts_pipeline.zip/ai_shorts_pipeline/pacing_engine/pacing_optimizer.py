def optimize_pacing(clips):
    print("Optimizing pacing")
