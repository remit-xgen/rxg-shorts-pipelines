from downloader.downloader import download_video
from video_processing.normalize_video import normalize_video

def run_pipeline(video_url: str):
    print("Starting AI Shorts Pipeline")
    video_path = download_video(video_url)
    normalized = normalize_video(video_path)
    print("Pipeline stage complete:", normalized)

if __name__ == "__main__":
    run_pipeline("example_url")
