def compute_viral_score(clip):
    return 0.5
