def detect_speech_hooks(transcript):
    print("Detect speech hooks")
