def detect_visual_hooks(video):
    print("Detect visual hooks")
