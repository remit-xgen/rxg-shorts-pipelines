def generate_hooks(data):
    print("Generate hooks")
