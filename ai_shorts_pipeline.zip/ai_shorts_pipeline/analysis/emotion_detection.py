def detect_emotions(video_path:str):
    print("Detecting emotions")
