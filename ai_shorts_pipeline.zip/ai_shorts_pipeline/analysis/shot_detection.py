def detect_shots(video_path:str):
    print("Detecting shots")
