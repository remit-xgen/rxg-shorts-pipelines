def detect_gestures(video_path:str):
    print("Detecting gestures")
