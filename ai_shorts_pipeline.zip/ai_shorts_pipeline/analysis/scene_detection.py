def detect_scenes(video_path:str):
    print("Detecting scenes")
