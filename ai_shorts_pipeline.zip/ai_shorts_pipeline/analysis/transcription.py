def transcribe(audio_path:str):
    print("Transcribing audio")
