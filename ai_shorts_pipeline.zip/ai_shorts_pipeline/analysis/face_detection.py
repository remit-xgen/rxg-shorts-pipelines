def detect_faces(video_path:str):
    print("Detecting faces")
