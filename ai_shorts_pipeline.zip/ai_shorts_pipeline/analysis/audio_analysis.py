def analyze_audio(audio_path:str):
    print("Analyzing audio")
