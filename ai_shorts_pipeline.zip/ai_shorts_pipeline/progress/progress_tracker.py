class ProgressTracker:
    def update(self, stage:str):
        print(f"[Progress] {stage}")
