def extract_clip(video_path,start,end):
    print("Extracting clip")
