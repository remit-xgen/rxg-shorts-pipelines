def crop_portrait(video_path):
    print("Cropping portrait")
